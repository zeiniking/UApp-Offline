package com.zain.uapp

import android.Manifest
import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.content.Intent
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.util.UUID
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val adapter: BluetoothAdapter? by lazy { BluetoothAdapter.getDefaultAdapter() }
    private val appUuid: UUID = UUID.fromString("7b9a2c10-5a8e-4a19-9c20-1a2b3c4d5e6f")
    private val audioUuid: UUID = UUID.fromString("4d5e6f70-8a9b-4c1d-8e2f-3a4b5c6d7e8f")
    private val prefs by lazy { getSharedPreferences("uapp", MODE_PRIVATE) }
    private val myId by lazy { prefs.getString("user_id", null) ?: (1000 + (Math.random()*9000).toInt()).toString().also { prefs.edit().putString("user_id", it).apply() } }
    private lateinit var status: TextView
    private lateinit var deviceSpinner: Spinner
    private lateinit var log: LinearLayout
    private lateinit var input: EditText
    private var devices: List<BluetoothDevice> = emptyList()
    private val discovered = linkedMapOf<String, BluetoothDevice>()
    private var discoveryReceiverRegistered = false
    private lateinit var communityLog: LinearLayout
    private lateinit var communityInput: EditText
    private val discoveryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: android.content.Context?, intent: Intent?) {
            if (intent?.action != BluetoothDevice.ACTION_FOUND) return
            val d = extractBluetoothDevice(intent)
            if (d != null) {
                try { discovered[d.address] = d; refreshDeviceChoices() } catch (_: SecurityException) { }
            }
        }
    }
    @Volatile private var socket: BluetoothSocket? = null
    @Volatile private var writer: PrintWriter? = null
    @Volatile private var serverSocket: BluetoothServerSocket? = null
    @Volatile private var audioServerSocket: BluetoothServerSocket? = null
    @Volatile private var audioSocket: BluetoothSocket? = null
    @Volatile private var audioRunning = false
    @Volatile private var incomingCall = false
    @Volatile private var outgoingCall = false
    private lateinit var callStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        buildUi()
        askPermissions()
    }


    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("uapp_messages", "UApp messages and calls", NotificationManager.IMPORTANCE_HIGH).apply { description = "Bluetooth chat messages and incoming calls" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun showIncomingNotification(title: String, message: String) {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        try {
            val notification = NotificationCompat.Builder(this, "uapp_messages")
                .setSmallIcon(android.R.drawable.stat_notify_chat)
                .setContentTitle(title)
                .setContentText(message.take(180))
                .setStyle(NotificationCompat.BigTextStyle().bigText(message.take(500)))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .build()
            NotificationManagerCompat.from(this).notify((System.currentTimeMillis() % 100000).toInt(), notification)
        } catch (_: SecurityException) { }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 20, 18, 16); setBackgroundColor(Color.rgb(247,247,252)) }
        root.addView(TextView(this).apply { text="UApp • Bluetooth Chat"; textSize=25f; gravity=Gravity.CENTER; setTextColor(Color.rgb(35,32,70)) })
        root.addView(TextView(this).apply { text="Aap ka permanent ID: $myId"; textSize=17f; gravity=Gravity.CENTER; setPadding(0,10,0,8); setTextColor(Color.DKGRAY) })
        status = TextView(this).apply { text="Bluetooth status check karein"; gravity=Gravity.CENTER; setPadding(0,6,0,10); textSize=14f }
        root.addView(status)
        root.addView(btn("Bluetooth ON karein") { enableBluetooth() })
        root.addView(btn("Nearby devices scan karein") { scanNearbyDevices() })
        root.addView(btn("Paired phones refresh karein") { refreshPairedDevices() })
        deviceSpinner = Spinner(this)
        root.addView(deviceSpinner)
        root.addView(btn("Is phone par messages receive karein") { startServer() })
        root.addView(btn("Selected paired phone se connect karein") { connectSelected() })
        callStatus = TextView(this).apply { text="Audio call: idle"; gravity=Gravity.CENTER; textSize=15f; setPadding(0,8,0,4) }
        root.addView(callStatus)
        root.addView(btn("Audio Call karein") { startOutgoingCall() })
        root.addView(btn("Incoming Call Accept karein") { acceptIncomingCall() })
        root.addView(btn("Call Hang Up") { stopAudioCall() })
        root.addView(btn("Disconnect") { disconnect() })
        root.addView(TextView(this).apply { text="Setup: dono phones ki Android Bluetooth Settings mein pehle pair karein. Ek phone par Receive, doosre par paired phone select karke Connect. Internet/Wi-Fi ki zaroorat nahi."; textSize=13f; setTextColor(Color.DKGRAY); setPadding(0,8,0,8) })
        val scroll = ScrollView(this)
        log = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(2,6,2,6) }
        scroll.addView(log)
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        input = EditText(this).apply { hint="Message likhein"; maxLines=3 }
        root.addView(input)
        root.addView(btn("Send Message") { sendMessage() })
        root.addView(TextView(this).apply { text="🌐 Community • Everyone nearby"; textSize=19f; setTextColor(Color.rgb(0,105,95)); setPadding(0,16,0,4) })
        root.addView(TextView(this).apply { text="Default community — messages are shared with the currently connected Bluetooth friend."; textSize=12f; setTextColor(Color.DKGRAY) })
        val communityScroll = ScrollView(this).apply { setBackgroundColor(Color.WHITE) }
        communityLog = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(8,6,8,6) }
        communityScroll.addView(communityLog)
        root.addView(communityScroll, LinearLayout.LayoutParams(-1,160))
        communityInput = EditText(this).apply { hint="Community message likhein"; maxLines=2 }
        root.addView(communityInput)
        root.addView(btn("Send to Community") { sendCommunityMessage() })
        setContentView(root)
        addLog("Bluetooth-only version. Pehle Android Settings mein phones pair karein.")
        refreshPairedDevices()
        addCommunityLog("UApp Community pehle se bani hui hai.")
    }

    @Suppress("DEPRECATION")
    private fun extractBluetoothDevice(intent: Intent): BluetoothDevice? {
        return if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
        else intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
    }

    private fun btn(label: String, action: () -> Unit) = Button(this).apply { text=label; setOnClickListener { action() } }

    private fun askPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            val requested = mutableListOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) requested.add(Manifest.permission.POST_NOTIFICATIONS)
            val needed = requested.filter { ContextCompat.checkSelfPermission(this,it) != PackageManager.PERMISSION_GRANTED }
            if (needed.isNotEmpty()) ActivityCompat.requestPermissions(this, needed.toTypedArray(), 100)
        } else if (Build.VERSION.SDK_INT >= 23) {
            val needed = listOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.RECORD_AUDIO).filter { ContextCompat.checkSelfPermission(this,it) != PackageManager.PERMISSION_GRANTED }
            if (needed.isNotEmpty()) ActivityCompat.requestPermissions(this, needed.toTypedArray(), 100)
        }
    }

    private fun hasConnectPermission() = Build.VERSION.SDK_INT < 31 || ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    private fun enableBluetooth() {
        val a = adapter
        if (a == null) { addLog("Is phone mein Bluetooth hardware nahi hai."); return }
        if (!hasConnectPermission()) { askPermissions(); return }
        if (!a.isEnabled) startActivityForResult(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), 101)
        else { status.text="Bluetooth ON hai"; refreshPairedDevices() }
    }

    private fun refreshPairedDevices() {
        try {
            if (!hasConnectPermission()) { askPermissions(); return }
            val a = adapter ?: run { addLog("Bluetooth supported nahi."); return }
            devices = ((a.bondedDevices?.toList() ?: emptyList()) + discovered.values).distinctBy { it.address }.sortedBy { it.name ?: it.address }
            refreshDeviceChoices()
            status.text = if (a.isEnabled) "Bluetooth ON • ${devices.size} nearby/paired device(s)" else "Bluetooth OFF"
        } catch (e: SecurityException) { addLog("Bluetooth permission allow karein.") }
    }

    private fun refreshDeviceChoices() {
        try {
            val a = adapter ?: return
            devices = ((a.bondedDevices?.toList() ?: emptyList()) + discovered.values).distinctBy { it.address }.sortedBy { it.name ?: it.address }
            val labels = if (devices.isEmpty()) listOf("Nearby phone nahi mila — doosre phone ko discoverable karein") else devices.map {
                val paired = try { it.bondState == BluetoothDevice.BOND_BONDED } catch (_: Exception) { false }
                "${it.name ?: "Unknown device"} • ${if (paired) "Paired" else "Nearby — pair first"} • ${it.address}"
            }
            deviceSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        } catch (_: SecurityException) { }
    }

    private fun scanNearbyDevices() {
        if (!hasConnectPermission() || (Build.VERSION.SDK_INT >= 31 && ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED)) {
            askPermissions(); addLog("Nearby scan ke liye Bluetooth permissions allow karein."); return
        }
        val a = adapter ?: return
        try {
            if (!a.isEnabled) { enableBluetooth(); return }
            if (!discoveryReceiverRegistered) {
                val filter = IntentFilter(BluetoothDevice.ACTION_FOUND)
                if (Build.VERSION.SDK_INT >= 33) registerReceiver(discoveryReceiver, filter, RECEIVER_NOT_EXPORTED) else registerReceiver(discoveryReceiver, filter)
                discoveryReceiverRegistered = true
            }
            discovered.clear()
            refreshDeviceChoices()
            if (a.isDiscovering) a.cancelDiscovery()
            val started = a.startDiscovery()
            addLog(if (started) "Nearby Bluetooth scan start. Doosre phone ko Bluetooth settings mein discoverable rakhein." else "Scan start nahi hua. Bluetooth permissions aur settings check karein.")
        } catch (e: Exception) { addLog("Nearby scan error: ${e.message}") }
    }

    private fun addCommunityLog(message: String) {
        val tv = TextView(this).apply { text=message; textSize=14f; setTextColor(Color.rgb(40,40,55)); setPadding(5,7,5,7) }
        communityLog.addView(tv)
    }

    private fun sendCommunityMessage() {
        val message = communityInput.text.toString().trim()
        if (message.isEmpty()) return
        val w = writer
        if (w == null || socket?.isConnected != true) { addCommunityLog("Aapka message local list mein save nahi hua: pehle community ke kisi member se Bluetooth connect karein."); return }
        thread {
            try {
                w.println("COMMUNITY|$myId|$message")
                runOnUiThread { addCommunityLog("You: $message"); communityInput.setText("") }
            } catch (e: Exception) { runOnUiThread { addCommunityLog("Message send nahi hua: ${e.message}") } }
        }
    }

    private fun startServer() {
        if (!hasConnectPermission()) { askPermissions(); return }
        val a = adapter ?: return
        if (!a.isEnabled) { addLog("Pehle Bluetooth ON karein."); enableBluetooth(); return }
        thread {
            try {
                serverSocket?.close()
                startAudioListener()
                serverSocket = a.listenUsingRfcommWithServiceRecord("UAppChat", appUuid)
                runOnUiThread { status.text="Receive mode: connection ka intezar hai…"; addLog("Receive mode ON. Doosre phone se Connect karein.") }
                val accepted = serverSocket!!.accept()
                socket = accepted
                setupConnectedSocket(accepted)
            } catch (e: Exception) { runOnUiThread { addLog("Receive connection band/failed: ${e.message}") } }
        }
    }

    private fun connectSelected() {
        if (!hasConnectPermission()) { askPermissions(); return }
        if (devices.isEmpty() || deviceSpinner.selectedItemPosition !in devices.indices) { addLog("Pehle dono phones ko Android Bluetooth Settings mein pair karein."); return }
        val device = devices[deviceSpinner.selectedItemPosition]
        try {
            if (device.bondState != BluetoothDevice.BOND_BONDED) {
                addLog("Yeh device abhi paired nahi. Android Bluetooth Settings mein pair karein, phir refresh karein.")
                return
            }
        } catch (_: SecurityException) { }
        thread {
            try {
                startAudioListener()
                adapter?.cancelDiscovery()
                runOnUiThread { status.text="${device.name ?: "Phone"} se connect ho raha hai…" }
                val s = device.createRfcommSocketToServiceRecord(appUuid)
                s.connect()
                socket = s
                setupConnectedSocket(s)
            } catch (e: Exception) { runOnUiThread { status.text="Connection nahi hua"; addLog("Connect failed: ${e.message}. Dono phones pair hain aur doosre par Receive mode ON hai?") } }
        }
    }

    private fun setupConnectedSocket(s: BluetoothSocket) {
        socket = s
        writer = PrintWriter(s.outputStream, true)
        runOnUiThread { status.text="Bluetooth connected"; addLog("Connected to ${try { s.remoteDevice.name ?: s.remoteDevice.address } catch (_: Exception) { "friend" }}") }
        thread {
            try {
                val reader = BufferedReader(InputStreamReader(s.inputStream, Charsets.UTF_8))
                while (true) {
                    val line = reader.readLine() ?: break
                    when {
                        line.startsWith("COMMUNITY|") -> {
                            val body = line.substringAfter("|", "").substringAfter("|", "Community message")
                            runOnUiThread { addCommunityLog("Member: $body") }
                            showIncomingNotification("UApp Community", body)
                        }
                        line == "UAPP_CALL_REQUEST" -> { runOnUiThread { incomingCall = true; callStatus.text="Incoming audio call — Accept dabayein"; addLog("Friend audio call kar raha hai.") }; showIncomingNotification("Incoming UApp audio call", "Aapka Bluetooth contact call kar raha hai.") }
                        line == "UAPP_CALL_ACCEPT" -> {
                            runOnUiThread { outgoingCall = false; callStatus.text="Audio call connect ho rahi hai…" }
                            connectAudioToFriend(s.remoteDevice)
                        }
                        line == "UAPP_CALL_END" -> runOnUiThread { stopAudioCall(false); addLog("Friend ne call end kar di.") }
                        else -> { runOnUiThread { addLog("Friend: $line") }; showIncomingNotification("UApp message", line) }
                    }
                }
            } catch (_: Exception) { }
            runOnUiThread { status.text="Disconnected"; addLog("Connection close ho gaya.") }
        }
    }

    private fun startAudioListener() {
        if (audioServerSocket != null) return
        thread {
            try {
                val a = adapter ?: return@thread
                if (!hasConnectPermission()) return@thread
                val ss = a.listenUsingRfcommWithServiceRecord("UAppAudio", audioUuid)
                audioServerSocket = ss
                while (!isFinishing) {
                    val incoming = ss.accept()
                    audioSocket = incoming
                    runOnUiThread { callStatus.text="Audio call connected"; addLog("Bluetooth audio call connected.") }
                    runAudio(incoming)
                }
            } catch (e: Exception) {
                if (!isFinishing) runOnUiThread { addLog("Audio listener: ${e.message}") }
            }
        }
    }

    private fun startOutgoingCall() {
        val w = writer
        if (w == null || socket?.isConnected != true) { addLog("Pehle Bluetooth chat connect karein."); return }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            askPermissions(); addLog("Microphone permission allow karein."); return
        }
        outgoingCall = true
        w.println("UAPP_CALL_REQUEST")
        callStatus.text="Calling… doosre phone par Accept dabayein"
        addLog("Audio call request bhej di.")
    }

    private fun acceptIncomingCall() {
        if (!incomingCall) { addLog("Koi incoming call nahi hai."); return }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            askPermissions(); addLog("Microphone permission allow karein."); return
        }
        incomingCall = false
        writer?.println("UAPP_CALL_ACCEPT")
        callStatus.text="Call accept ho gayi; connect ho raha hai…"
        startAudioListener()
    }

    private fun connectAudioToFriend(device: BluetoothDevice) {
        thread {
            try {
                val a = adapter ?: return@thread
                a.cancelDiscovery()
                val s = device.createRfcommSocketToServiceRecord(audioUuid)
                s.connect()
                audioSocket = s
                runOnUiThread { callStatus.text="Audio call connected"; addLog("Audio call connected. Mic/speaker active.") }
                runAudio(s)
            } catch (e: Exception) {
                runOnUiThread { callStatus.text="Audio call failed"; addLog("Audio call connect nahi hui: ${e.message}") }
            }
        }
    }

    private fun runAudio(s: BluetoothSocket) {
        if (audioRunning) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            runOnUiThread { addLog("Microphone permission nahi mili.") }; return
        }
        audioRunning = true
        val rate = 8000
        val minIn = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT).coerceAtLeast(2048)
        val minOut = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT).coerceAtLeast(2048)
        var recorder: AudioRecord? = null
        var player: AudioTrack? = null
        try {
            val am = getSystemService(AUDIO_SERVICE) as AudioManager
            am.mode = AudioManager.MODE_IN_COMMUNICATION
            am.isSpeakerphoneOn = true
            val rec = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, minIn * 2)
            val play = AudioTrack(AudioManager.STREAM_VOICE_CALL, rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT, minOut * 2, AudioTrack.MODE_STREAM)
            recorder = rec
            player = play
            rec.startRecording(); play.play()
            val inputStream = s.inputStream; val outputStream = s.outputStream
            val readThread = thread {
                val buffer = ByteArray(minIn)
                try { while (audioRunning && s.isConnected) { val n = rec.read(buffer,0,buffer.size); if (n > 0) synchronized(outputStream) { outputStream.write(buffer,0,n); outputStream.flush() } } } catch (_: Exception) { }
            }
            val buffer = ByteArray(minOut)
            while (audioRunning && s.isConnected) {
                val n = inputStream.read(buffer)
                if (n <= 0) break
                play.write(buffer,0,n)
            }
            readThread.interrupt()
        } catch (e: Exception) {
            runOnUiThread { addLog("Audio stream ruk gayi: ${e.message}") }
        } finally {
            audioRunning = false
            try { recorder?.stop() } catch (_: Exception) { }; try { recorder?.release() } catch (_: Exception) { }
            try { player?.stop() } catch (_: Exception) { }; try { player?.release() } catch (_: Exception) { }
            try { s.close() } catch (_: Exception) { }
            val am = getSystemService(AUDIO_SERVICE) as AudioManager
            am.mode = AudioManager.MODE_NORMAL
            am.isSpeakerphoneOn = false
            audioSocket = null
            runOnUiThread { callStatus.text="Audio call ended" }
        }
    }

    private fun stopAudioCall(notifyFriend: Boolean = true) {
        audioRunning = false
        if (notifyFriend) try { writer?.println("UAPP_CALL_END") } catch (_: Exception) { }
        try { audioSocket?.close() } catch (_: Exception) { }
        callStatus.text="Audio call ended"
    }

    private fun sendMessage() {
        val message = input.text.toString().trim()
        if (message.isEmpty()) return
        val w = writer
        if (w == null || socket?.isConnected != true) { addLog("Abhi Bluetooth friend connected nahi hai."); return }
        thread {
            try {
                w.println(message)
                runOnUiThread { addLog("You: $message"); input.setText("") }
            } catch (e: Exception) { runOnUiThread { addLog("Message send nahi hua: ${e.message}") } }
        }
    }

    private fun disconnect() {
        try { socket?.close() } catch (_: Exception) { }
        try { serverSocket?.close() } catch (_: Exception) { }
        stopAudioCall()
        try { audioServerSocket?.close() } catch (_: Exception) { }
        socket = null; writer = null; serverSocket = null; audioServerSocket = null
        status.text="Disconnected"; addLog("Disconnected.")
    }

    private fun addLog(message: String) {
        val tv = TextView(this).apply { text=message; textSize=14f; setTextColor(Color.rgb(40,40,55)); setPadding(6,7,6,7) }
        log.addView(tv)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 101) refreshPairedDevices()
    }

    override fun onDestroy() {
        disconnect()
        try { if (discoveryReceiverRegistered) unregisterReceiver(discoveryReceiver) } catch (_: Exception) { }
        super.onDestroy()
    }
}
