UApp Bluetooth + Audio Call + Nearby Scan + Community (BETA)

Is updated starter project mein:
- Nearby Bluetooth device scan button (doosra phone discoverable mode mein hona chahiye)
- Paired phones list aur one-to-one text messaging
- Experimental Bluetooth RFCOMM audio-call code
- Pehle se bani hui “Community • Everyone nearby” screen aur community message send/receive (current connected peer tak)

Mobile-only build:
1. Is ZIP ko download karein aur extract karein.
2. Project ke andar ki files GitHub repository ke root mein upload karein (ZIP ko sirf upload kar dena build workflow ke liye kaafi nahi jab tak workflow extract na kare).
3. Cloud GitHub Actions/Gradle se assembleDebug chalayein.
4. APK output: app/build/outputs/apk/debug/app-debug.apk

Pairing/scan:
- Dono phones par Bluetooth ON karein.
- Receiver phone par “Is phone par messages receive karein” dabayein.
- Doosre phone ko Android Bluetooth settings mein discoverable rakhein aur “Nearby devices scan karein” dabayein.
- Connect ke liye phones ko Android Bluetooth settings mein pair karna zaroori hai; phir refresh aur connect karein.
- Android 12+ par Bluetooth scan/connect aur microphone permissions allow karein.

IMPORTANT LIMITATIONS:
- Yeh abhi beta starter code hai; cloud build aur do real Android phones par test karna zaroori hai.
- Nearby scan sirf discoverable Bluetooth devices ko dhoondhne ki koshish karta hai. Android ki permissions, device visibility aur OS rules ki wajah se har phone automatically nazar aana guaranteed nahi.
- Community abhi connected Bluetooth peer ko message bhejti hai; multiple users ka shared group server nahi hai.
- TRUE MESH/CHAIN RELAY abhi implement nahi: phones doosre phones ke messages automatically forward nahi karte, is liye range abhi Bluetooth ke direct link se aage nahi barhti. Is ke liye multi-peer connections, message IDs, duplicate prevention, relay rules aur background handling ka alag implementation chahiye.
- Permanent 4-digit ID local display hai, global unique ID nahi.
- Audio call code experimental 8 kHz mono PCM over Bluetooth RFCOMM use karta hai. Quality, echo aur device compatibility guaranteed nahi; foreground mein rakhein aur test karein.
